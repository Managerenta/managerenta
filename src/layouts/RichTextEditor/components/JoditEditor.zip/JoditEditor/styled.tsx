import styled from "styled-components";
import { Box } from "@/components";

export const JoditEditorStyled = styled(Box)<{
	$isReadOnly: boolean;
	$border?: string;
}>`
	.jodit-container {
		border: ${({ $border }) => $border || "none"};

		iframe {
			width: 100%;
			height: 100%;
			max-height: 600px;
		}

		// jodit-container jodit jodit_theme_default jodit-wysiwyg_mode

		.jodit-toolbar__box,
		.jodit-status-bar {
			display: ${({ $isReadOnly }) => ($isReadOnly ? "none" : "inherit")};
		}
	}
`;

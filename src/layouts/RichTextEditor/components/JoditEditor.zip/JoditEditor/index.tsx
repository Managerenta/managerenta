import { useContext, useMemo } from "react";
import JoditReact, { JoditReactProps } from "jodit-react-ts";
// import "jodit/es2021/jodit.min.css";
import { ContextProvider } from "@/hooks";
import { JoditEditorStyled } from "./styled";

interface IProps {
	height?: string;
	background?: string;
	color?: string;
	border?: string;
	onChange: (v: string) => void;
	isReadOnly?: boolean;
}

export default function JoditEditor({
	height,
	background,
	color,
	onChange,
	isReadOnly = false,
	border,
}: IProps) {
	const { env } = useContext(ContextProvider);

	const joditProps = useMemo(() => {
		const params: JoditReactProps = {
			config: {
				license: env.JODIT_LICENCE_KEY,
				readonly: isReadOnly,
				placeholder: "Start typings...",
				caches: true,
				width: "100%",
				toolbar: true,
				uploader: {
					insertImageAsBase64URI: true,
				},
				showTooltip: true,
				colorPickerDefaultTab: "color",
				// // autofocus: true,
				toolbarButtonSize: "large",
				// allowTabNavigation: true,
				// // theme: "dark",
				saveModeInStorage: true,
				toolbarSticky: false,
				style: {
					background: background || "var(--White)",
					color: color || "var(--Black)",
					height: height || "100%",
				},
				minHeight: height || "100%",
				statusbar: true,
				// // extraPlugins: ["emoji"],
				history: {
					enable: true,
					maxHistoryLength: 100,
				},
				enableDragAndDropFileToEditor: true,
				imageeditor: {
					crop: true,
					resize: true,
				},
				hidePoweredByJodit: true,
				// allowResizeY: false,
				// allowResizeTags: true,
				useSearch: true,
				video: {
					defaultWidth: "100%",
					defaultHeight: "400px",
				},
			},
			onChange: onChange || (() => {}),
			// defaultValue: data,
		};

		return params;
	}, [
		env.JODIT_LICENCE_KEY,
		isReadOnly,
		onChange,
		// data,
		// border,
		background,
		color,
		height,
	]);

	return (
		<JoditEditorStyled $isReadOnly={isReadOnly} $border={border}>
			<JoditReact {...joditProps} />;
		</JoditEditorStyled>
	);
}
